import { Events } from 'swap.app'


export default new Events()
