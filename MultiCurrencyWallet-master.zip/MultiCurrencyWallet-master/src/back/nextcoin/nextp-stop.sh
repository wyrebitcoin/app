pm2 delete nextp
echo 'nextp stopped!'