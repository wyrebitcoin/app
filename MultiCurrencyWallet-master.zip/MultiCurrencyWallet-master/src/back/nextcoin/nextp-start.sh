pm2 start nextp.js
echo 'nextp started!'