export default {
  BTC: 8,
  ETH: 18,
  SWAP: 18,
  USDT: 6,
  NEXT: 8,
  default: 18,
}
