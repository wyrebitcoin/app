import SwapApp from './microbot'


const { app } = SwapApp


export default SwapApp
export {
  app,
}

