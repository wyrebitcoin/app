export default orders => id => {
  // swap.app.services.orders
  return orders.getByKey(id)
}
