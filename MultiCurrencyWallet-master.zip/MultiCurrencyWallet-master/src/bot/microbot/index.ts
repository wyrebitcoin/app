import { SwapApp } from './app'


export default SwapApp
