export default (swap) => swap
