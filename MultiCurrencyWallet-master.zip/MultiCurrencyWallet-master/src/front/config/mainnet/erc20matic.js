export default {
  wbtc: {
    address: '0x1bfd67037b42cf73acf2047067bd4f2c47d9bfd6',
    decimals: 8,
    fullName: 'Wrapped Bitcoin',
    canSwap: true,
  },
}
