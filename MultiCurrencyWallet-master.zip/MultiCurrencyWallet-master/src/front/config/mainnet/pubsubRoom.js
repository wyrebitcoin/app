export default {
  swarm: '/dns4/webrtc-star-1.swaponline.io/tcp/443/wss/p2p-webrtc-star/',
}
