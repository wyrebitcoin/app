export default [
    1,      // ETH Mainnet
    56,     // BSC Mainnet
    137,    // MATIC Mainnet
    42161,  // ARBITRUM Mainnet
    100,    // XDAO Mainnet
    250,    // FTM Mainnet
    43114,    // AVAX Mainnet
]