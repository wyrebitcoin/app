// resolve object in webpack
export default __CONFIG__
