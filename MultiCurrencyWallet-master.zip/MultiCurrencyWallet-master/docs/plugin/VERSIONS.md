# MCWallet WordPress plugin versions

- Free version - https://wordpress.org/plugins/multi-currency-wallet/
- Pro version - https://codecanyon.net/item/multicurrency-crypto-wallet-and-exchange-widgets-for-wordpress/23532064


## Version differences

| Feature \ Version            | Free | Pro |
|------------------------------|------|-----|
| Set&collect transaction fees | -    | +   |
| More frequent updates        | -    | +   |
