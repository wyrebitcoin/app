# Installation service

**We do**: only WP-plugin installation and activation service.

**We don't** offer support for plugins, configuration, or verification of compatibility with already installed plugins.

## Requirements

- extra $100 (paypal/crypto)
- wp-admin access (login and pass)

## How to

- contact our support https://t.me/swaponlinebot, request for `Installation service`
- send wp-admin access, make payment
