# Chrome extension

## Where to install
https://chrome.google.com/webstore/detail/swaponline/oldojieloelkkfeacfinhcngmbkepnlm

## How to build & install manually
- `npm i`
- `npm run build:chrome-extension-testnet`
- Go to `chrome://extensions` and enable developer mode
- Drag&drop the `./build-chrome-extension` folder