Gitcoin grants (https://gitcoin.co/grants/):
1) мультивалютный грант
2) просят добавить инфу о себе чтобы Maximize Your Impact! - Verified users have up to 150% of their donation amount count towards the match fund algorithm. Unverified users — only 50%. Maximize your match by verifying with identity partners.
3) заполняется все по форме (https://gitcoin.co/grants/new)
4) не понятно сколько ревьювится и что еще нужно будет сделать после создания
