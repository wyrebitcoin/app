# How to configure

- `/config`
- `/externalConfigs` - for domains..


## Configuration files priority

- domain-network
- domain
- default-network
- default
- standart config from `config/network`
